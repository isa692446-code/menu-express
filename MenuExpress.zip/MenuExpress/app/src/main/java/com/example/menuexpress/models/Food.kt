package com.example.menuexpress.models

import java.io.Serializable // Importe isso

// Classe de dados baseada no exemplo foods.json
data class Food(
    val id: Int,
    val name: String,
    val description: String,
    val price: Double,
    val image: String // URL da imagem
) : Serializable // Adicione isso