package com.example.menuexpress.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.menuexpress.databinding.ItemFoodBinding // Layout que criaremos a seguir
import com.example.menuexpress.models.Food
import com.bumptech.glide.Glide // <-- IMPORTE O GLIDE

// Adaptador para o RecyclerView da Tela Principal [cite: 20, 27]
class FoodAdapter(
    private val foodList: List<Food>,
    private val onClick: (Food) -> Unit // Ação de clique para ir para DetalheActivity
) : RecyclerView.Adapter<FoodAdapter.FoodViewHolder>() {

    // ViewHolder para cada item da lista
    inner class FoodViewHolder(private val binding: ItemFoodBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(food: Food) {

            // ATUALIZE AQUI: Remova comentários e adicione o Glide
            Glide.with(binding.root.context) // Carrega a imagem
                .load(food.image)           // Da URL do JSON
                .centerCrop()               // Corta para caber (como no XML)
                .into(binding.ivFoodImage)  // No seu ImageView

            binding.tvFoodName.text = food.name
            binding.tvFoodDescription.text = food.description
            binding.tvFoodPrice.text = "R$ ${"%.2f".format(food.price)}"

            binding.root.setOnClickListener {
                onClick(food)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val binding = ItemFoodBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return FoodViewHolder(binding)
    }

    override fun getItemCount() = foodList.size

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        holder.bind(foodList[position])
    }
}