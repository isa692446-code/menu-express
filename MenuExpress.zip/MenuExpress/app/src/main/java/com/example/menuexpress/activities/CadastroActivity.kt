package com.example.menuexpress.activities

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.menuexpress.databinding.ActivityCadastroBinding
import com.example.menuexpress.models.User
import com.example.menuexpress.network.ApiClient
import com.google.gson.Gson
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Cadastro"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.btnCadastrar.setOnClickListener {
            performRegistration()
        }
    }

    private fun performRegistration() {
        val nome = binding.etNomeCadastro.text.toString()
        val email = binding.etEmailCadastro.text.toString()
        val senha = binding.etSenhaCadastro.text.toString()

        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }

        // Criando o objeto User para cadastro
        val newUser = User(nome = nome, email = email, pass = senha)

        // Chamada de Rede (Retrofit)
        ApiClient.instance.registerUser(newUser)
            .enqueue(object : Callback<ResponseBody> {

                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        // Sucesso (201 Created)
                        Toast.makeText(this@CadastroActivity, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show()
                        finish() // Volta para a tela de Login

                    } else {
                        // Erro (Ex: 400 - E-mail já existe)
                        val errorBody = response.errorBody()?.string()
                        val errorMessage = try {
                            Gson().fromJson(errorBody, Map::class.java)["message"] as? String
                        } catch (e: Exception) {
                            "Erro ao cadastrar"
                        }
                        Toast.makeText(this@CadastroActivity, errorMessage, Toast.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Log.e("CadastroActivity", "Falha na conexão: ${t.message}", t)
                    Toast.makeText(this@CadastroActivity, "Erro de conexão: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}