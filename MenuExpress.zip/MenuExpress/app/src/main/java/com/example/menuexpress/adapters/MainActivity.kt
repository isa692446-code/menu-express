package com.example.menuexpress.adapters

class MainActivity {
}