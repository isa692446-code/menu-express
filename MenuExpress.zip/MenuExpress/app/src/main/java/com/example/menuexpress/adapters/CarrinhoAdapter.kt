package com.example.menuexpress.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.menuexpress.databinding.ItemCarrinhoBinding
import com.example.menuexpress.models.Food

// ATUALIZE O CONSTRUTOR para incluir o 'onDeleteClick'
class CarrinhoAdapter(
    private val foodList: MutableList<Food>, // Mude de List para MutableList
    private val onDeleteClick: (Food) -> Unit // Lambda para o clique
) : RecyclerView.Adapter<CarrinhoAdapter.CarrinhoViewHolder>() {

    inner class CarrinhoViewHolder(private val binding: ItemCarrinhoBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(food: Food) {
            binding.tvItemName.text = food.name
            binding.tvItemPrice.text = "R$ ${"%.2f".format(food.price)}"

            // Define o clique no botão de deletar
            binding.btnDeleteItem.setOnClickListener {
                onDeleteClick(food)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarrinhoViewHolder {
        val binding = ItemCarrinhoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CarrinhoViewHolder(binding)
    }

    override fun getItemCount() = foodList.size

    override fun onBindViewHolder(holder: CarrinhoViewHolder, position: Int) {
        holder.bind(foodList[position])
    }
}