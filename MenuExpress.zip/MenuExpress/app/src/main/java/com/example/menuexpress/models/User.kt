package com.example.menuexpress.models

// Classe de dados para Login e Cadastro
data class User(
    val id: String? = null, // Pode ser útil para o back-end
    val nome: String? = null, // Para o cadastro
    val email: String,
    val pass: String // 'senha'
)