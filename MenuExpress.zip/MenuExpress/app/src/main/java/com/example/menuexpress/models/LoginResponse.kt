package com.example.menuexpress.models

// Resposta JSON que o Node envia no login
data class LoginResponse(
    val message: String,
    val user: UserData
) {
    data class UserData(
        val id: String,
        val nome: String,
        val email: String
    )
}