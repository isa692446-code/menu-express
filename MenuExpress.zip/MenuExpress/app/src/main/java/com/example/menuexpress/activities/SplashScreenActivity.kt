package com.example.menuexpress.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.menuexpress.databinding.ActivitySplashScreenBinding

class SplashScreenActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Esconde a ActionBar se ela estiver visível
        supportActionBar?.hide()

        // Handler para redirecionar após 2 segundos [cite: 21, 40]
        Handler(Looper.getMainLooper()).postDelayed({
            // Redireciona para a LoginActivity [cite: 41]
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish() // Fecha a SplashScreen
        }, 2000) // 2000ms = 2 segundos
    }
}