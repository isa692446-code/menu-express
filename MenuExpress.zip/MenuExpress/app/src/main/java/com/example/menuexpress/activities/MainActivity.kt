package com.example.menuexpress.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
// Importe estes se o Android Studio pedir (embora não sejam mais necessários se você remover os métodos de menu)
// import android.view.Menu
// import android.view.MenuItem
import com.example.menuexpress.adapters.FoodAdapter
import com.example.menuexpress.databinding.ActivityMainBinding
import com.example.menuexpress.models.Food
import com.example.menuexpress.network.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var foodAdapter: FoodAdapter
    private var foodList: MutableList<Food> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Cardápio Principal"

        setupRecyclerView()
        loadMenu() // Carrega o cardápio da API

        // Listener para o botão flutuante (ESTÁ CORRETO)
        binding.fabCart.setOnClickListener {
            // Abre a CarrinhoActivity
            val intent = Intent(this, CarrinhoActivity::class.java)
            startActivity(intent)
        }

    } // FIM DO MÉTODO onCreate

    /*
     * REMOVEMOS os métodos 'onCreateOptionsMenu' e 'onOptionsItemSelected'
     * porque você decidiu usar o 'fabCart' (botão flutuante)
     */

    private fun setupRecyclerView() {
        foodAdapter = FoodAdapter(foodList) { foodItem ->
            // Ação de clique: abrir DetalheActivity
            val intent = Intent(this, DetalheActivity::class.java)

            // Passamos o objeto Food inteiro
            intent.putExtra("FOOD_OBJECT", foodItem)

            startActivity(intent)
        }
        binding.rvFoods.adapter = foodAdapter
    }

    private fun loadMenu() {
        ApiClient.instance.getFoods()
            .enqueue(object : Callback<List<Food>> {
                override fun onResponse(call: Call<List<Food>>, response: Response<List<Food>>) {
                    if (response.isSuccessful) {
                        response.body()?.let { foodsFromApi ->
                            foodList.clear() // Limpa a lista antiga
                            foodList.addAll(foodsFromApi) // Adiciona os novos
                            foodAdapter.notifyDataSetChanged() // Notifica o adapter
                        }
                    } else {
                        Toast.makeText(this@MainActivity, "Erro ao carregar o cardápio", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<List<Food>>, t: Throwable) {
                    Log.e("MainActivity", "Falha na conexão: ${t.message}", t)
                    Toast.makeText(this@MainActivity, "Erro de conexão: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
    }
}