package com.example.menuexpress.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.menuexpress.auth.UserManager
import com.example.menuexpress.databinding.ActivityLoginBinding
import com.example.menuexpress.models.LoginResponse
import com.example.menuexpress.models.User
import com.example.menuexpress.network.ApiClient
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Login"

        binding.btnEntrar.setOnClickListener {
            performLogin()
        }

        binding.tvCadastrar.setOnClickListener {
            val intent = Intent(this, CadastroActivity::class.java)
            startActivity(intent)
        }
    }

    private fun performLogin() {
        val email = binding.etEmail.text.toString()
        val senha = binding.etSenha.text.toString()

        if (email.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Preencha e-mail e senha", Toast.LENGTH_SHORT).show()
            return
        }

        // Criando o objeto User para enviar no body da requisição
        val loginUser = User(email = email, pass = senha)

        // Chamada de Rede (Retrofit)
        ApiClient.instance.loginUser(loginUser)
            .enqueue(object : Callback<LoginResponse> {

                // Resposta BEM SUCEDIDA (Ex: 200 OK)
                override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                    if (response.isSuccessful) {
                        // Sucesso!
                        val loginResponse = response.body()
                        val userName = loginResponse?.user?.nome ?: "Usuário"
                        val userEmail = loginResponse?.user?.email

                        // Salva o e-mail do usuário logado
                        UserManager.userEmail = userEmail

                        Toast.makeText(this@LoginActivity, "Bem-vindo, $userName!", Toast.LENGTH_SHORT).show()

                        // Navega para a MainActivity
                        val intent = Intent(this@LoginActivity, MainActivity::class.java)
                        startActivity(intent)
                        finish()

                    } else {
                        // Falha (Ex: 401 Não Autorizado - Senha errada)
                        val errorBody = response.errorBody()?.string()
                        val errorMessage = try {
                            // Tenta extrair a mensagem "E-mail ou senha inválidos." do JSON
                            Gson().fromJson(errorBody, Map::class.java)["message"] as? String
                        } catch (e: Exception) {
                            "E-mail ou senha inválidos"
                        }
                        Toast.makeText(this@LoginActivity, errorMessage, Toast.LENGTH_LONG).show()
                    }
                }

                // Falha NA CONEXÃO (Ex: Servidor desligado ou sem internet)
                override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                    Log.e("LoginActivity", "Falha na conexão: ${t.message}", t)
                    Toast.makeText(this@LoginActivity, "Erro de conexão: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
    }
}