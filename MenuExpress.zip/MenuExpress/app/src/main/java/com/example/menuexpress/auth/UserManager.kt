package com.example.menuexpress.auth

// Objeto Singleton para manter o e-mail do usuário logado
object UserManager {
    var userEmail: String? = null
}