package com.example.menuexpress.activities

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.menuexpress.auth.UserManager
import com.example.menuexpress.databinding.ActivityDetalheBinding
import com.example.menuexpress.models.Food
import com.example.menuexpress.network.ApiClient
import com.example.menuexpress.network.ApiService
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.bumptech.glide.Glide // <-- IMPORTE O GLIDE

class DetalheActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetalheBinding
    private var currentFood: Food? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetalheBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Detalhes do Prato"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Recupera o objeto Food serializado
        currentFood = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra("FOOD_OBJECT", Food::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra("FOOD_OBJECT") as? Food
        }

        // Se o objeto for nulo, algo deu errado.
        if (currentFood == null) {
            Toast.makeText(this, "Erro ao carregar detalhes do prato", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Popula a UI
        populateUi(currentFood!!)

        // Ação do botão "Adicionar ao Carrinho"
        binding.btnAddCarrinho.setOnClickListener {
            addToCart()
        }
    }

    private fun populateUi(food: Food) {
        binding.tvDetalheNome.text = food.name
        binding.tvDetalheDescricao.text = food.description
        binding.tvDetalhePreco.text = "R$ ${"%.2f".format(food.price)}"

        // ATUALIZE AQUI: Remova comentários e adicione o Glide
        Glide.with(this) // Carrega a imagem
            .load(food.image) // Da URL do JSON
            .centerCrop() // Corta para caber
            .into(binding.ivDetalheImagem) // No seu ImageView de detalhe
    }

    private fun addToCart() {
        val userEmail = UserManager.userEmail

        // Verifica se o usuário está logado e se o prato foi carregado
        if (userEmail == null || currentFood == null) {
            Toast.makeText(this, "Erro: Faça login novamente.", Toast.LENGTH_SHORT).show()
            return
        }

        // Cria o objeto de requisição para o carrinho
        val itemRequest = ApiService.CartItemRequest(userEmail = userEmail, foodItem = currentFood!!)

        ApiClient.instance.addToCart(itemRequest)
            .enqueue(object: Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@DetalheActivity, "${currentFood!!.name} adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@DetalheActivity, "Erro ao adicionar ao carrinho", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Log.e("DetalheActivity", "Falha na conexão: ${t.message}", t)
                    Toast.makeText(this@DetalheActivity, "Erro de conexão: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
    }


    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}