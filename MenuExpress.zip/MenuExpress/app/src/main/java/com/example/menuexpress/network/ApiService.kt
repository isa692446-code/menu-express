package com.example.menuexpress.network

import com.example.menuexpress.models.Food
import com.example.menuexpress.models.LoginResponse
import com.example.menuexpress.models.User
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {

    @POST("register")
    fun registerUser(@Body user: User): Call<ResponseBody>

    @POST("login")
    fun loginUser(@Body user: User): Call<LoginResponse> // Atualizado de ResponseBody

    @GET("foods")
    fun getFoods(): Call<List<Food>>

    // --- NOVAS ROTAS PARA O CARRINHO ---

    // DTO (Data Transfer Object) para enviar um item ao carrinho
    data class CartItemRequest(val userEmail: String, val foodItem: Food)

    @POST("cart/add")
    fun addToCart(@Body item: CartItemRequest): Call<ResponseBody>

    @GET("cart/{userEmail}")
    fun getCart(@Path("userEmail") email: String): Call<List<Food>>

    // DTO para remover item do carrinho
    data class CartRemoveRequest(val userEmail: String, val foodId: Int)

    // NOVA FUNÇÃO
    @POST("cart/remove")
    fun removeFromCart(@Body item: CartRemoveRequest): Call<ResponseBody>

    // --- NOVA FUNÇÃO PARA LIMPAR O CARRINHO ---

    data class CartClearRequest(val userEmail: String)

    @POST("cart/clear")
    fun clearCart(@Body request: CartClearRequest): Call<ResponseBody>
}