package com.example.menuexpress.activities

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.menuexpress.adapters.CarrinhoAdapter
import com.example.menuexpress.auth.UserManager
import com.example.menuexpress.databinding.ActivityCarrinhoBinding
import com.example.menuexpress.models.Food
import com.example.menuexpress.network.ApiClient
import com.example.menuexpress.network.ApiService
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CarrinhoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCarrinhoBinding
    private lateinit var carrinhoAdapter: CarrinhoAdapter

    // Mude de var para val (lista mutável)
    private val cartItems: MutableList<Food> = mutableListOf()
    private var userEmail: String? = null // Guardar o email do usuário

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCarrinhoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Carrinho"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        userEmail = UserManager.userEmail
        if (userEmail == null) {
            Toast.makeText(this, "Erro de autenticação. Faça login novamente.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        setupRecyclerView()
        loadCartItems()

        binding.btnFinalizarPedido.setOnClickListener {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Seu carrinho está vazio!", Toast.LENGTH_SHORT).show()
            } else {
                performCheckout() // Chama a nova função de checkout
            }
        }
    }

    private fun setupRecyclerView() {
        // Passe a lista E a função de clique (lambda)
        carrinhoAdapter = CarrinhoAdapter(cartItems) { foodItem ->
            // Isso será chamado quando o botão de deletar for clicado
            performRemoveItem(foodItem)
        }
        binding.rvCarrinho.adapter = carrinhoAdapter
        binding.btnFinalizarPedido.setOnClickListener {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Seu carrinho está vazio!", Toast.LENGTH_SHORT).show()
            } else {
                performCheckout() // Chama a nova função de checkout
            }
        }
    }

    private fun performCheckout() {
        if (userEmail == null) return // Verificação de segurança

        val clearRequest = ApiService.CartClearRequest(userEmail = userEmail!!)

        ApiClient.instance.clearCart(clearRequest)
            .enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        // A MENSAGEM DE SIMULAÇÃO VEM AQUI
                        Toast.makeText(this@CarrinhoActivity, "Pedido finalizado com sucesso!", Toast.LENGTH_SHORT).show()

                        // Limpa a UI
                        cartItems.clear()
                        carrinhoAdapter.notifyDataSetChanged()
                        calculateTotal()

                    } else {
                        Toast.makeText(this@CarrinhoActivity, "Erro ao finalizar o pedido.", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Log.e("CarrinhoActivity", "Falha na conexão: ${t.message}", t)
                    Toast.makeText(this@CarrinhoActivity, "Erro de conexão: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
    }

    // Função para remover o item
    private fun performRemoveItem(food: Food) {
        // Se userEmail for nulo (embora já tenhamos verificado no onCreate)
        if (userEmail == null) return

        val removeRequest = ApiService.CartRemoveRequest(userEmail = userEmail!!, foodId = food.id)

        ApiClient.instance.removeFromCart(removeRequest)
            .enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@CarrinhoActivity, "${food.name} removido.", Toast.LENGTH_SHORT).show()

                        // Atualiza a UI (remove da lista local e notifica o adapter)
                        cartItems.remove(food)
                        carrinhoAdapter.notifyDataSetChanged()
                        calculateTotal() // Recalcula o total

                    } else {
                        Toast.makeText(this@CarrinhoActivity, "Erro ao remover item.", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Log.e("CarrinhoActivity", "Falha na conexão: ${t.message}", t)
                    Toast.makeText(this@CarrinhoActivity, "Erro de conexão: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
    }

    private fun loadCartItems() {
        // (Código existente, mas use a variável userEmail!!)
        ApiClient.instance.getCart(userEmail!!)
            .enqueue(object : Callback<List<Food>> {
                override fun onResponse(call: Call<List<Food>>, response: Response<List<Food>>) {
                    if (response.isSuccessful) {
                        response.body()?.let { items ->
                            cartItems.clear()
                            cartItems.addAll(items)
                            carrinhoAdapter.notifyDataSetChanged()
                            calculateTotal() // Mudei o nome da função
                        }
                    } else {
                        Toast.makeText(this@CarrinhoActivity, "Erro ao carregar o carrinho", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onFailure(call: Call<List<Food>>, t: Throwable) {
                    // ... (código existente)
                }
            })
    }

    // Apenas mudei o nome da função (de calculateTotal(items) para calculateTotal())
    private fun calculateTotal() {
        val total = cartItems.sumOf { it.price }
        binding.tvTotalPrice.text = "R$ ${"%.2f".format(total)}"
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}